import React from 'react'
import Coming_soon from '../../component/Coming_soon'

const Recruitment = () => {
  return (
    <div><Coming_soon/></div>
  )
}

export default Recruitment