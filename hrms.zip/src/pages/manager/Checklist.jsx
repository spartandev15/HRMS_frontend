import React from 'react'
import Coming_soon from '../../component/Coming_soon'

const Checklist = () => {
  return (
    <div><Coming_soon/></div>
  )
}

export default Checklist